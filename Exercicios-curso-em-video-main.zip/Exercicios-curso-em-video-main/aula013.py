print('=' * 8, 'Tabuada', '=' * 8)
n = int(input('Digite o número: '))
for c in range(1,11):
    print(f'{n} x {c} = {n * c}')
print('=' * 10, 'FIM', '=' * 10)
