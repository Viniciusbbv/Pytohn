print('=' * 8, 'Tabuada', '=' * 8)
numero = int(input('Digite um numero para ver sua tabuada: '))
for c in range(1,11):
    print(f'{numero} x {c} = {numero * c}')
print('=' * 10, 'Fim', '=' * 10)