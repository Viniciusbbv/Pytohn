for c in range(0, 51, 2):
    print(c)