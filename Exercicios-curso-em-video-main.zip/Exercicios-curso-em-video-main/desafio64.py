n = 0
count = 0
n = int(input('numero: ')) 
while n != 999:
    count = count + n
    n = int(input('numero: '))
print(count)