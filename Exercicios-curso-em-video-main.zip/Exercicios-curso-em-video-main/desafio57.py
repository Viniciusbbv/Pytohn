sexo = str(input('sexo')).upper()
while sexo not in 'MF':
     sexo = str(input('erro, sexo')).upper()