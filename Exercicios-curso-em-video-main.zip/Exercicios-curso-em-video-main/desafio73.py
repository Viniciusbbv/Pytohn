times = ['Palmeiras', 'Flamengo', 'Cruzeiro', 'Internacional', 'Fluminense',
'Corinthians', 'Athletico-PR', 'Atlético', 'Fortaleza', 'São Paulo', 'América',
'Botafogo', 'Santos', 'Goiás', 'Red Bull Bragantino', 'Coritiba']
print(f'lista de times do brasileirao: {times}')
print(f'os 5 primeiros sao: {times[0:5]}')
print(f'os 5 ultimos sao: {times[-4:]}')
print(f'ordem alfabetica: {sorted(times)}')
print(times.index('Santos')+1)