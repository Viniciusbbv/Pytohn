prefixos='abcdefg'
sufixos='ack'
for lete in prefixos:
    print(lete + sufixos)
