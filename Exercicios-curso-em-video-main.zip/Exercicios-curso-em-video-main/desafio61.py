pt = int(input('primeiro termo: '))
r = int(input('razao: '))
n = 1
while n <= 10:
    print(f'{pt}-', end='')
    n += 1
    pt += r
print('Fim')
    

    