import time
for c in range(11):
    print(c)
    time.sleep(1)
print('KABUM')