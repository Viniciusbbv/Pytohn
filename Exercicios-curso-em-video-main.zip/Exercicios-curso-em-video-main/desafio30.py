numero = float(input('Digite um numero para saber se é par ou impar '))
if numero % 2 == 0:
    print('numero par')
else:
    print('numero impar')